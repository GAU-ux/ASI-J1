
# Folder for PDF documents

Folder used for PDF documents used to train some OpenAI Machine Learning model.

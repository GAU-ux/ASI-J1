
# Dynamic crypto files

This folder contains your server's cryptography related system files that are dynamically
changed for some reasons, and should be kept across updates.

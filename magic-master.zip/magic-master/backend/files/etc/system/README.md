
# System module's settings and dynamically changed files

This folder contains your server's system files that are dynamically changed for some reasons,
and should be kept across updates.

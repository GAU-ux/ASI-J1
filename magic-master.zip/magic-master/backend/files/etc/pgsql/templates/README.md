
# PostgreSQL samples scripts

This folder contains example scripts for PostgreSQL, such as for instance SQL scripts creating databases, etc for you.

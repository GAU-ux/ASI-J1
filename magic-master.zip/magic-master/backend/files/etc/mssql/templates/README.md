
# Samples folder for MS SQL scripts

This folder contains example SQL scripts for Microsoft SQL server

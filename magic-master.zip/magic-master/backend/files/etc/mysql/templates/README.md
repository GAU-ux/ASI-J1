
# MySQL samples scripts

This folder contains example scripts for MySQL, such as for instance SQL scripts creating databases, etc for you.

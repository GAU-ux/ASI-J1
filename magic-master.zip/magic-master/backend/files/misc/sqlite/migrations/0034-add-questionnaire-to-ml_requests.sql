
alter table ml_requests add column questionnaire int not null default 0;

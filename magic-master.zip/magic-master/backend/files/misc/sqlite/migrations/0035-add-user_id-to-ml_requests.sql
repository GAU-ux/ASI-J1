
alter table ml_requests add column user_id varchar(40) null;

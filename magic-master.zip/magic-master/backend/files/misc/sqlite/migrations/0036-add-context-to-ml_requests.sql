
alter table ml_requests add column context int not null default 0;

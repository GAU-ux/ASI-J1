
alter table ml_types add column cached integer not null default 0;

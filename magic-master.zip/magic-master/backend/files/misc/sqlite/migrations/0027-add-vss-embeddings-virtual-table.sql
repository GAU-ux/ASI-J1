
create virtual table vss_ml_training_snippets using vss0(
  embedding_vss(1536)
);


alter table questions add column name varchar(40) null;


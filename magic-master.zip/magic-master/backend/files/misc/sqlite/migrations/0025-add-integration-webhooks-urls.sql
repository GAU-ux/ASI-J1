
alter table ml_types add column webhook_incoming_url text null;
alter table ml_types add column webhook_outgoing_url text null;

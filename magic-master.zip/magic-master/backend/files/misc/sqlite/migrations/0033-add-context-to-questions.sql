
alter table questions add column context int not null default 0;

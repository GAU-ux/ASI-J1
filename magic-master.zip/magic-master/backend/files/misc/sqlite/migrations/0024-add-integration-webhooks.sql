
alter table ml_types add column webhook_incoming text null;
alter table ml_types add column webhook_outgoing text null;


alter table questions add column type varchar(40) not null default "question";


alter table questionnaires add column action varchar(40) null;


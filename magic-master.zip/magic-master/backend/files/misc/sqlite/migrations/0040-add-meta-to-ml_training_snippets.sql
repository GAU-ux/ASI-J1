
alter table ml_training_snippets add column meta varchar(40) null;


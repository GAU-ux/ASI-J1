
alter table ml_types add column system_message text null;

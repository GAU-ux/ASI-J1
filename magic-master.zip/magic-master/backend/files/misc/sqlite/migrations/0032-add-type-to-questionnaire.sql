
alter table questionnaires add column type varchar(40) not null default "single-shot";

import { [[component-name]] } from './components/[[component-folder]]/[[component-filename]]';
import { [[component-edit-name]] } from './components/[[component-folder]]/modals/[[component-edit-filename]]';

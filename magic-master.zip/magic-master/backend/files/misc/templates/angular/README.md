
# Dark Angular frontend template

This template is similar to the default angular template, except it creates a dark theme, and
contains some other changes, such that the default paging size is 25 records, etc.

<div class="image-container">
    <img src="https://servergardens.files.wordpress.com/2020/10/magic-dark-theme.png" alt="Screenshot of template">
</div>

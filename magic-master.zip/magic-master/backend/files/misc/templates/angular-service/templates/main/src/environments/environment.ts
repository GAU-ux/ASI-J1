export const environment = {
  production: false,

  // The URL to your backend API.
  apiUrl: '[[apiUrl]]',

  // The domain for your backend API. Needed for "oauth0".
  apiDomain: '[[environmentDomain]]',
};

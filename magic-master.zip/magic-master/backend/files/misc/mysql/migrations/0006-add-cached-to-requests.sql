
alter table ml_types add column cached int not null default 0;

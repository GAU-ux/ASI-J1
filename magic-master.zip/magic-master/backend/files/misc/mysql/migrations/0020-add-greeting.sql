
alter table ml_types add column greeting text null;


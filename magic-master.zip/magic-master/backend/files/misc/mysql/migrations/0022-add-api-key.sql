
alter table ml_types add column api_key text null;


alter table ml_types add column base_url text null;



alter table ml_types add column prefix text null;

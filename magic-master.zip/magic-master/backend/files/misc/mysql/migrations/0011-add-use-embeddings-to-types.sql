
alter table ml_types add column use_embeddings int not null default 0;

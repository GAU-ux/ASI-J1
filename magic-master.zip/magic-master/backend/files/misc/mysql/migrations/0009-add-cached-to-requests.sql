
alter table ml_requests add column cached int null;

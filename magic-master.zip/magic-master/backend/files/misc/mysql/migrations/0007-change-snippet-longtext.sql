
alter table ml_training_snippets modify completion longtext not null ;


alter table ml_requests add column cached smallint null;


alter table ml_types add column use_embeddings smallint not null default 0;

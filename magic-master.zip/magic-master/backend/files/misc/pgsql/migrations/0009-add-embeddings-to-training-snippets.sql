
alter table ml_training_snippets add column embedding text null;


alter table ml_types add column max_context_tokens integer;
alter table ml_types add column max_request_tokens integer;



alter table ml_types add api_key ntext null;

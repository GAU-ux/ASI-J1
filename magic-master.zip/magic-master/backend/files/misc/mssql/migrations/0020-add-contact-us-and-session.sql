
alter table ml_types add contact_us ntext null;
alter table ml_types add lead_email ntext null;
alter table ml_requests add session ntext null;
alter table ml_training_snippets add cached int null;


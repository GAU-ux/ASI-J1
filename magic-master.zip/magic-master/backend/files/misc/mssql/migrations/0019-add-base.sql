
alter table ml_types add base_url ntext null;


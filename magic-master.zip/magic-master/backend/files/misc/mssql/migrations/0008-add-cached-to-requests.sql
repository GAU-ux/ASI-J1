
alter table ml_requests add cached int null;

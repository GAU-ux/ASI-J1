
alter table ml_types add cached int not null default 0;

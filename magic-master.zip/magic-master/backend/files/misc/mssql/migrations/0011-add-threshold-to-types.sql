
alter table ml_types add threshold decimal(7,6) not null default 0.8;

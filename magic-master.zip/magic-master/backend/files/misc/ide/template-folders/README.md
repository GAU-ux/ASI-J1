
# Template folders for Hyper IDE

This folder contains template folder for Hyper IDE and specifically its macro system.

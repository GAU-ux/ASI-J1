
# Your startup folder

All Hyperlambda files inside of this folder, or sub-folders within this folder will
automatically execute every time Magic is starting, and/or your module is being installed
in a Magic backend.

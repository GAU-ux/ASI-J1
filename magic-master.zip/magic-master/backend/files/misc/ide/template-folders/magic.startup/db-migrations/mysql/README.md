
# MySQL database migration scripts

This folder contains your MySQL database migration scripts, and each SQL scripts will be sequentially
executed in alphabetical order.



# Email authentication templates

This folder contains your authentication email templates, allowing you to edit
them as you see fit, to better serve your specific purpose.

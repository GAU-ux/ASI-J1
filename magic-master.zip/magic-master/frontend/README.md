# Aista Magic Cloud frontend

This is Magic's frontend dashboard, allowing you to manage your backend cloudlet.

## Developing locally

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

# Contributon to Magic

In order to contribute to Magic, we need your employer's consent that you are legally allowed to contribute to open source projects.
This implies at the minimum having your closest upwards _"C level executive"_ send you an email confirming that there it's OK for
you to contribute to Magic, allowing us to sub-license your work any ways we see fit, for then to forward that email to info@aista.com.
We also need your explicit consent, implying you are fine with Aista, Ltd sub-licensing your code, any ways we see fit.

Hence, if you want to contribute to Magic, you will need to send two emails to info@aista.com as explained further up. Otherwise
we cannot for legal reasons accept your contribution.
